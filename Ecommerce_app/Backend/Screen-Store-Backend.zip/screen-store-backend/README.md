# Screen Store Backend (Node.js + Express + MongoDB)

## Setup
1. Install Node.js LTS.
2. Open this folder in VS Code.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set `MONGO_URI` to your MongoDB local or Atlas connection string.
6. Set `JWT_SECRET` to a long random secret.
7. Run `npm run dev`.

API runs at `http://localhost:5000`. Check `http://localhost:5000/api/health`.

## Routes
- `POST /api/auth/signup` body: `{ "name":"Isha", "email":"isha@example.com", "password":"securepass123" }`
- `POST /api/auth/login` body: `{ "email":"isha@example.com", "password":"securepass123" }`
- `GET /api/products`
- `GET /api/products/:id`
- `POST /api/products` (Bearer token required)
- `PUT /api/products/:id` (Bearer token required)
- `DELETE /api/products/:id` (Bearer token required)

Product example:
`{ "name":"Casual Sneakers", "category":"Shoes", "price":1499, "oldPrice":1999, "rating":4.6, "image":"https://example.com/shoe.jpg", "tag":"Bestseller" }`

This is the API starter. The existing React frontend must be updated to fetch products and use the auth endpoints. Cart and order persistence are the next backend modules to add. Product write routes require login but do not yet enforce an admin role; don't deploy publicly as-is.
